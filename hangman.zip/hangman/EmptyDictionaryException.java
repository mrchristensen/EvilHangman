package hangman;

public class EmptyDictionaryException extends Exception {
}
